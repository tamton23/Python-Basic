#!/usr/bin/python
item_one = 1
item_two = 2
item_three = 3
total = item_one + \
	item_two + \
	item_three
print total

days = ['Monday', 'Tuesday', 'Wednesday',
	'Thursday', 'Friday']

print days[0]
print days

import sys; x = 'foo'; sys.stdout.write(x + '\n')