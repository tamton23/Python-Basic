#!/usr/bin/python
x = 5.5
type(x)
x = 'Hello'
type(x)
x = 1234567
x ** 2
z= 3+2j
t= 2-1j
x+t