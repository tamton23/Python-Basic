#!/usr/bin/python
if True:
	print "Answer"
	print "True"
else:
	print "False"