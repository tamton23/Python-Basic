#!/usr/bin/python
print 'Hello World!'
message = """This message will
 	... span several lines."""
print message