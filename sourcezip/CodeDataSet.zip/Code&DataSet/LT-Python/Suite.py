#!/usr/bin/python
def hi(name):
	print 'Hello ' + name
	print 'Have a good day!'
hi('hoa')